from setuptools import setup

__version__ = "0.0.1"


setup(
    name="cse446utils",
    version=__version__,
    author="CSE 446 Staff",

    packages=["utils"],
)
